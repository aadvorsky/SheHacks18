package com.example.meganbailey.fakenews;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button calculate = (Button) findViewById(R.id.button);
        calculate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                EditText url = (EditText) findViewById(R.id.url);
                TextView title = (TextView) findViewById(R.id.title);
                TextView result = (TextView) findViewById(R.id.result);
                TextView is = (TextView) findViewById(R.id.is);

                //turn url into a string from an EditText so as to compare it to other strings
                String urlString = url.getText().toString();

                switch (urlString){
                    case "https://politics.theonion.com/trump-insists-he-never-thought-about-firing-mueller-fe-1822461545":
                        result.setText("Very Liberal");
                        is.setText("   is...");
                        title.setText("'Trump Insists He Never Thought About Firing Mueller, Feeding Him To Pack Of Rabid Dogs, Mounting Head In Oval Office As Trophy'");
                        result.setTextColor(Color.BLUE);
                        break;
                    case "https://www.cnn.com/2018/01/27/politics/steve-wynn-mar-a-lago-speech/index.html":
                        result.setText("Liberal");
                        is.setText("   is...");
                        title.setText("'Scandal-ridden GOP donor spoke at Mar-a-Lago last week'");
                        result.setTextColor(Color.BLUE);
                        break;
                    case "http://www.kcci.com/article/car-surfing-cat-sparks-police-call-but-owner-says-pet-loves-it/15901387":
                        result.setText("Nuetral");
                        is.setText("   is...");
                        title.setText("'Car-surfing cat sparks police call, but owner says he loves it'");
                        result.setTextColor(Color.GRAY);
                        break;
                    case "http://www.foxnews.com/politics/2018/01/27/in-optimistic-state-union-trump-will-tout-safe-strong-and-proud-america.html":
                        result.setText("Conservative");
                        is.setText("   is...");
                        title.setText("'In optimistic State of the Union, Trump will tout 'safe, strong and proud America'");
                        result.setTextColor(Color.RED);
                        break;
                    case "https://www.indy100.com/article/conservatives-republicans-more-attractive-left-wing-lefties-hotter-rolfe-daus-peterson-carl-palmaer-8181196":
                        result.setText("Very Conservative");
                        is.setText("   is...");
                        title.setText("'Conservatives are more attractive than liberals, study finds'");
                        result.setTextColor(Color.RED);
                        break;
                    default:
                        result.setText("Invalid URL");
                        title.setText(" ");
                        is.setText("");
                        result.setTextColor(Color.GRAY);
                        break;
                }
            }
        });

    }
}
